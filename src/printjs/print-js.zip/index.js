import './sass/index.styl'
import print from './js/init'

const printJS = print.init

if (typeof window !== 'undefined') {
  // if (!!window.ActiveXObject || 'ActiveXObject' in window) {
  //   remone_header_and_footer()
  // }
  window.printJS = printJS
}
export default printJS
