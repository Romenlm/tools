<template>
  <div>
    <el-button @click="btn">打印</el-button>
    <div ref="print" id="printJS-form"> <!--设置dem元素的id和ref-->
      <!--此处为要打印的内容-->
      <div v-for="item of 10" :key="'print_'+item" class="list-item" >{{item}}</div>
      <div class="image-item">
      </div>
    </div>
  </div>
</template>

<script>
  /**
   * 关于打印任意节点内的内容demo
   *
   * 使用注意事项
   * 1. 使用 utils.print()方法进行打印处理，首先需要引入 utils
   *
   * 2. 使用时样式需要写在方法中一起作为参数传过去
   *
   * 3. 如果时图片只能使用背景图片，不能使用<img>标签，并将图片放到 public/images 文件下，作为静态资源，否则不能正常加载
   *
   * 4. 在ie浏览器上面运行需要设置打印背景图片和样式，设置过程在 src/views/demo/ie 文件中
   *
   */
  import utils from '../../utils/util'
  export default {
    name: "prints",
    methods: {
      btn(){
        this.print()
      },

      print(){
        utils.print({
          printable: 'printJS-form', // dom元素id
          type: 'html',
          // 需要打印的节点样式，需要作为参数传递过去，否则不能正常渲染，对于图片，为了兼容ie浏览器，只能使用背景图片，如果使用<img>标签，在google chrome中可以正常使用
          // 但是在ie浏览器中无法正常渲染。图片需要放到 public/images 文件下，作为静态资源，否则不能正常加载
          style: `
          .list-item {
            height: 30px;
            background-color: #dedede;
            font-size: 20px;
            margin: 5px 0px;
            border: 1px solid #000000;
          }
          .image-item{
            width: 177px;
            height: 176px;
            background-size: 100%;
            border: 1px solid red;
            background: url(/images/ebankSeal.png);
          }
          `
        })
      }
    }
  }
</script>

<style scoped>
  .list-item {
    height: 30px;
    background-color: #dedede;
    font-size: 20px;
    margin: 5px 0px;
    border: 1px solid #000000;
  }
  .image-item{
    width: 177px;
    height: 176px;
    background-size: 100%;
    border: 1px solid red;
    background: url(/images/ebankSeal.png);
  }
</style>
